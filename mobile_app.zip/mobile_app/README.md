# AI Business Agent — Mobile App

Android-first Flutter client for the local AI Business Agent backend.

## Included screens
- Command Center
- Connected Websites
- Content Sources
- Task History
- Settings / backend connection

## How it works
The heavy automation (Playwright, local AI/Ollama, SQLite) runs on your computer. The Android app connects to that computer over your local network and sends commands.

## Create Android platform files (one time)
Install Flutter, open this folder, then run:

```bash
flutter create . --platforms=android
flutter pub get
flutter run
```

For an APK:

```bash
flutter build apk --release
```

The APK will be under `build/app/outputs/flutter-apk/app-release.apk`.

## Connect phone to PC
1. Start backend on PC on `0.0.0.0:8765`.
2. Keep phone and PC on the same Wi-Fi/LAN.
3. Find PC local IP, e.g. `192.168.1.10`.
4. In app Settings set: `http://192.168.1.10:8765`.

Do not expose the local backend directly to the public internet without authentication/TLS.
