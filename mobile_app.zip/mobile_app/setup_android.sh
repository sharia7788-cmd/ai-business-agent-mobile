#!/usr/bin/env bash
set -euo pipefail
exec "$(dirname "$0")/prepare_android.sh"
