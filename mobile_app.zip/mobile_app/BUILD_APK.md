# Android APK Build

## Option A — নিজের কম্পিউটারে

Flutter + Android Studio/Android SDK ইনস্টল থাকলে `mobile_app` ফোল্ডারে টার্মিনাল খুলে চালান:

```bash
./prepare_android.sh
flutter build apk --release
```

APK পাওয়া যাবে:

`build/app/outputs/flutter-apk/app-release.apk`

## Option B — GitHub Actions

এই project GitHub repository-তে upload/push করলে `.github/workflows/build-apk.yml` workflow চালানো যাবে। Workflow Flutter 3.47.5 সেটআপ করে release APK build করে `AI-Business-Agent-APK` artifact হিসেবে দেয়।

## Local backend connection

মোবাইল অ্যাপের Settings-এ কম্পিউটারের LAN IP দিন, যেমন:

`http://192.168.1.10:8765`

ফোন ও কম্পিউটার একই Wi-Fi/LAN-এ থাকতে হবে। Prototype-এর জন্য Android app-এ local HTTP cleartext traffic enabled রাখা হয়েছে। Production/public network-এ HTTPS ব্যবহার করুন।
