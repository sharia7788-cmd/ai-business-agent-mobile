#!/usr/bin/env bash
set -euo pipefail

# Generate Android platform files for this Flutter project.
flutter create . --platforms=android --org app.aibusinessagent --project-name ai_business_agent_mobile
flutter pub get

python3 - <<'PY'
from pathlib import Path
p = Path('android/app/src/main/AndroidManifest.xml')
s = p.read_text(encoding='utf-8')
perm = '    <uses-permission android:name="android.permission.INTERNET" />\n'
if 'android.permission.INTERNET' not in s:
    pos = s.find('>') + 1
    s = s[:pos] + '\n' + perm + s[pos:]
if 'android:usesCleartextTraffic=' not in s:
    s = s.replace('<application\n', '<application\n        android:usesCleartextTraffic="true"\n', 1)
# Friendly app label.
import re
s = re.sub(r'android:label="[^"]*"', 'android:label="AI Business Agent"', s, count=1)
p.write_text(s, encoding='utf-8')
PY

echo "Android platform prepared."
echo "Build with: flutter build apk --release"
