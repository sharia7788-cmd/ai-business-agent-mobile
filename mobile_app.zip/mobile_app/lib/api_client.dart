import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiClient {
  ApiClient(this.baseUrl);
  final String baseUrl;

  Uri _uri(String path) => Uri.parse('${baseUrl.replaceAll(RegExp(r'/$'), '')}$path');

  Future<bool> health() async {
    final r = await http.get(_uri('/health')).timeout(const Duration(seconds: 5));
    return r.statusCode < 400;
  }

  Future<List<dynamic>> getList(String path) async {
    final r = await http.get(_uri(path)).timeout(const Duration(seconds: 15));
    if (r.statusCode >= 400) throw Exception(r.body);
    return jsonDecode(r.body) as List<dynamic>;
  }

  Future<Map<String, dynamic>> getMap(String path) async {
    final r = await http.get(_uri(path)).timeout(const Duration(seconds: 15));
    if (r.statusCode >= 400) throw Exception(r.body);
    return jsonDecode(r.body) as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> post(String path, Map<String, dynamic> body) async {
    final r = await http.post(
      _uri(path),
      headers: {'content-type': 'application/json'},
      body: jsonEncode(body),
    ).timeout(const Duration(seconds: 20));
    if (r.statusCode >= 400) throw Exception(r.body);
    return jsonDecode(r.body) as Map<String, dynamic>;
  }
}
