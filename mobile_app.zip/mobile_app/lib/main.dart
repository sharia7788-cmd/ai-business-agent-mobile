import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'api_client.dart';

void main() => runApp(const AgentMobileApp());

class AgentMobileApp extends StatelessWidget {
  const AgentMobileApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'AI Business Agent',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.indigo,
        inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder()),
      ),
      home: const HomeShell(),
    );
  }
}

class AppState extends ChangeNotifier {
  String backendUrl = 'http://192.168.1.2:8765';
  List<dynamic> sources = [];
  List<dynamic> websites = [];
  List<dynamic> tasks = [];
  bool connected = false;
  String message = 'Not connected';

  ApiClient get api => ApiClient(backendUrl);

  Future<void> loadSaved() async {
    final p = await SharedPreferences.getInstance();
    backendUrl = p.getString('backendUrl') ?? backendUrl;
    notifyListeners();
    await refreshAll();
  }

  Future<void> setBackend(String url) async {
    backendUrl = url.trim();
    final p = await SharedPreferences.getInstance();
    await p.setString('backendUrl', backendUrl);
    notifyListeners();
    await refreshAll();
  }

  Future<void> refreshAll() async {
    try {
      connected = await api.health();
      sources = await api.getList('/api/sources');
      websites = await api.getList('/api/websites');
      tasks = await api.getList('/api/tasks');
      message = connected ? 'Connected' : 'Backend unavailable';
    } catch (e) {
      connected = false;
      message = 'Connection failed';
    }
    notifyListeners();
  }
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  final state = AppState();
  int index = 0;

  @override
  void initState() {
    super.initState();
    state.loadSaved();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      CommandPage(state: state),
      ProfilesPage(state: state, websites: true),
      ProfilesPage(state: state, websites: false),
      TasksPage(state: state),
      SettingsPage(state: state),
    ];
    return AnimatedBuilder(
      animation: state,
      builder: (context, _) => Scaffold(
        appBar: AppBar(
          title: const Text('AI Business Agent'),
          actions: [
            Padding(
              padding: const EdgeInsets.only(right: 12),
              child: Icon(state.connected ? Icons.cloud_done : Icons.cloud_off),
            )
          ],
        ),
        body: SafeArea(child: pages[index]),
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (v) => setState(() => index = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.auto_awesome), label: 'Command'),
            NavigationDestination(icon: Icon(Icons.language), label: 'Websites'),
            NavigationDestination(icon: Icon(Icons.source), label: 'Sources'),
            NavigationDestination(icon: Icon(Icons.task_alt), label: 'Tasks'),
            NavigationDestination(icon: Icon(Icons.settings), label: 'Settings'),
          ],
        ),
      ),
    );
  }
}

class CommandPage extends StatefulWidget {
  const CommandPage({super.key, required this.state});
  final AppState state;
  @override
  State<CommandPage> createState() => _CommandPageState();
}

class _CommandPageState extends State<CommandPage> {
  final command = TextEditingController(text: 'ঢাকা জব পোস্ট থেকে আজকের ৫০টা নতুন পোস্ট সংগ্রহ করে আমার ওয়েবসাইটে ক্যাটাগরি অনুযায়ী প্রস্তুত করো');
  int? sourceId;
  int? websiteId;
  bool autoPublish = false;
  bool busy = false;
  String status = 'Ready';

  Future<void> run() async {
    sourceId ??= widget.state.sources.isNotEmpty ? widget.state.sources.first['id'] as int : null;
    websiteId ??= widget.state.websites.isNotEmpty ? widget.state.websites.first['id'] as int : null;
    if (sourceId == null || websiteId == null) {
      setState(() => status = 'Source এবং Website profile আগে যোগ করুন');
      return;
    }
    setState(() { busy = true; status = 'Task তৈরি হচ্ছে…'; });
    try {
      final result = await widget.state.api.post('/api/commands', {
        'command': command.text.trim(),
        'source_profile_id': sourceId,
        'website_profile_id': websiteId,
        'auto_publish': autoPublish,
      });
      final id = result['id'] as int;
      setState(() => status = 'Task #$id queued');
      for (var i = 0; i < 120; i++) {
        await Future.delayed(const Duration(seconds: 2));
        final t = await widget.state.api.getMap('/api/tasks/$id');
        if (!mounted) return;
        setState(() => status = 'Task #$id: ${t['status']} • ${t['progress'] ?? 0}/${t['total'] ?? 0}');
        if (t['status'] == 'completed' || t['status'] == 'failed') break;
      }
      await widget.state.refreshAll();
    } catch (e) {
      setState(() => status = 'Error: $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.state.sources;
    final w = widget.state.websites;
    if (sourceId != null && !s.any((x) => x['id'] == sourceId)) sourceId = null;
    if (websiteId != null && !w.any((x) => x['id'] == websiteId)) websiteId = null;

    return RefreshIndicator(
      onRefresh: widget.state.refreshAll,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Command Center', style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 6),
          Text('বাংলা বা English-এ কাজ লিখুন।', style: Theme.of(context).textTheme.bodyMedium),
          const SizedBox(height: 16),
          DropdownButtonFormField<int>(
            value: sourceId,
            decoration: const InputDecoration(labelText: 'Source website'),
            items: s.map<DropdownMenuItem<int>>((x) => DropdownMenuItem(value: x['id'] as int, child: Text(x['name'].toString()))).toList(),
            onChanged: (v) => setState(() => sourceId = v),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<int>(
            value: websiteId,
            decoration: const InputDecoration(labelText: 'Target admin panel'),
            items: w.map<DropdownMenuItem<int>>((x) => DropdownMenuItem(value: x['id'] as int, child: Text(x['name'].toString()))).toList(),
            onChanged: (v) => setState(() => websiteId = v),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: command,
            minLines: 5,
            maxLines: 9,
            decoration: const InputDecoration(labelText: 'আপনার Command', hintText: 'যেমন: ৫০টা নতুন জব পোস্ট সংগ্রহ করে পোস্ট করো'),
          ),
          const SizedBox(height: 8),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            value: autoPublish,
            onChanged: (v) => setState(() => autoPublish = v),
            title: const Text('Auto Publish'),
            subtitle: const Text('Off রাখলে প্রথমে preview/prepare mode-এ থাকবে।'),
          ),
          const SizedBox(height: 8),
          FilledButton.icon(
            onPressed: busy ? null : run,
            icon: const Icon(Icons.play_arrow),
            label: Padding(
              padding: const EdgeInsets.symmetric(vertical: 14),
              child: Text(busy ? 'Working…' : 'Run Command'),
            ),
          ),
          const SizedBox(height: 14),
          Card(child: Padding(padding: const EdgeInsets.all(14), child: Text(status))),
        ],
      ),
    );
  }
}

class ProfilesPage extends StatelessWidget {
  const ProfilesPage({super.key, required this.state, required this.websites});
  final AppState state;
  final bool websites;

  @override
  Widget build(BuildContext context) {
    final list = websites ? state.websites : state.sources;
    return RefreshIndicator(
      onRefresh: state.refreshAll,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            children: [
              Expanded(child: Text(websites ? 'Connected Websites' : 'Content Sources', style: Theme.of(context).textTheme.headlineSmall)),
              IconButton(onPressed: state.refreshAll, icon: const Icon(Icons.refresh)),
            ],
          ),
          const SizedBox(height: 8),
          if (list.isEmpty)
            const Card(child: Padding(padding: EdgeInsets.all(18), child: Text('এখনো কোনো profile নেই। Backend API থেকে profile যোগ করুন; Visual Teach Mode পরের ধাপে যোগ হবে।'))),
          ...list.map((x) => Card(
            child: ListTile(
              leading: CircleAvatar(child: Icon(websites ? Icons.language : Icons.source)),
              title: Text(x['name'].toString()),
              subtitle: Text((websites ? x['base_url'] : x['list_url']).toString()),
              trailing: Icon((x['active'] == 1 || x['active'] == true) ? Icons.check_circle : Icons.pause_circle),
            ),
          )),
        ],
      ),
    );
  }
}

class TasksPage extends StatelessWidget {
  const TasksPage({super.key, required this.state});
  final AppState state;

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: state.refreshAll,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(children: [
            Expanded(child: Text('Task History', style: Theme.of(context).textTheme.headlineSmall)),
            IconButton(onPressed: state.refreshAll, icon: const Icon(Icons.refresh)),
          ]),
          const SizedBox(height: 8),
          if (state.tasks.isEmpty)
            const Card(child: Padding(padding: EdgeInsets.all(18), child: Text('কোনো task নেই।'))),
          ...state.tasks.map((t) {
            final st = t['status']?.toString() ?? 'unknown';
            final icon = st == 'completed' ? Icons.check_circle : st == 'failed' ? Icons.error : Icons.hourglass_top;
            return Card(
              child: ListTile(
                leading: Icon(icon),
                title: Text('Task #${t['id']} • $st'),
                subtitle: Text(t['command']?.toString() ?? '', maxLines: 3, overflow: TextOverflow.ellipsis),
                trailing: Text('${t['progress'] ?? 0}/${t['total'] ?? 0}'),
              ),
            );
          }),
        ],
      ),
    );
  }
}

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key, required this.state});
  final AppState state;
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late final TextEditingController backend;
  bool saving = false;

  @override
  void initState() {
    super.initState();
    backend = TextEditingController(text: widget.state.backendUrl);
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('Settings', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 16),
        TextField(
          controller: backend,
          keyboardType: TextInputType.url,
          decoration: const InputDecoration(
            labelText: 'Computer backend URL',
            hintText: 'http://192.168.1.10:8765',
            helperText: 'ফোন ও কম্পিউটার একই Wi‑Fi-তে থাকলে PC-এর local IP দিন।',
          ),
        ),
        const SizedBox(height: 12),
        FilledButton(
          onPressed: saving ? null : () async {
            setState(() => saving = true);
            await widget.state.setBackend(backend.text);
            if (mounted) setState(() => saving = false);
          },
          child: Text(saving ? 'Checking…' : 'Save & Test Connection'),
        ),
        const SizedBox(height: 16),
        Card(
          child: ListTile(
            leading: Icon(widget.state.connected ? Icons.check_circle : Icons.error_outline),
            title: Text(widget.state.connected ? 'Backend connected' : 'Backend not connected'),
            subtitle: Text(widget.state.backendUrl),
          ),
        ),
        const SizedBox(height: 12),
        const Card(
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Text('নোট: Playwright/Ollama automation কম্পিউটারে চলবে। মোবাইল অ্যাপ command পাঠাবে এবং task status দেখাবে।'),
          ),
        )
      ],
    );
  }
}
